class ZermeloManager {
  final String school;
  final String accessToken;

  ZermeloManager({
    this.school,
    this.accessToken,
  });
}
