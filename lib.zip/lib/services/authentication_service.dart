import 'package:zeta/locator.dart';
import 'package:zeta/zermelo/User/User.dart';
import 'package:zeta/services/analytics_service.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:zeta/zermelo/Zermelo.dart';

import 'package:zeta/main.dart';

class AuthenticationService {
  // final AnalyticsService _analyticsService = locator<AnalyticsService>();

  User _currentUser;
  User get currentUser => _currentUser;

  Future loginWithCode({
    @required String school,
    @required String code,
  }) async {
    try {
      dynamic accessToken = await Zermelo.getAccessToken(school, code);
      zermelo = Zermelo.getAPI(school, accessToken);

      _currentUser = await zermelo.users.get(id: "~me");

      await box.put('accessToken', accessToken);
      await box.put('school', school);

      return _currentUser != null;
    } catch (e) {
      return e.message;
    }
  }

  bool isUserLoggedIn() {
    return _currentUser != null;
  }

  // Future _populateCurrentUser(FirebaseUser user) async {
  //   if (user != null) {
  //     await _analyticsService.setUserProperties(
  //       userId: user.uid,
  //       userRole: _currentUser.,
  //     );
  //   }
  // }
}
