import 'package:zeta/locator.dart';
import 'package:zeta/zermelo/User/User.dart';
import 'package:zeta/services/analytics_service.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:zeta/zermelo/Zermelo.dart';

class ZermeloService {
  // User _zermelo;
  // User get api => _currentUser;

}
