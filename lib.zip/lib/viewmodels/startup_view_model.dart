import 'package:zeta/constants/route_names.dart';
import 'package:zeta/locator.dart';
import 'package:zeta/services/authentication_service.dart';
import 'package:zeta/services/navigation_service.dart';
import 'package:zeta/viewmodels/base_model.dart';

class StartUpViewModel extends BaseModel {
  final AuthenticationService _authenticationService =
      locator<AuthenticationService>();
  final NavigationService _navigationService = locator<NavigationService>();
  // final PushNotificationService _pushNotificationService =
  //     locator<PushNotificationService>();
  // final DynamicLinkService _dynamicLinkService = locator<DynamicLinkService>();

  Future handleStartUpLogic() async {
    print("handleStartUpLogic()");
    // await _dynamicLinkService.handleDynamicLinks();

    // Register for push notifications
    // await _pushNotificationService.initialise();

    var hasLoggedInUser = _authenticationService.isUserLoggedIn();
    print(hasLoggedInUser);

    if (hasLoggedInUser) {
      _navigationService.navigateTo(HomeViewRoute);
    } else {
      _navigationService.navigateTo(LoginViewRoute);
    }
  }
}
