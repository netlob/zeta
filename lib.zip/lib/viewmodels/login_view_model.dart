import 'package:flutter/material.dart';
import 'package:zeta/constants/route_names.dart';
import 'package:zeta/locator.dart';
import 'package:zeta/services/analytics_service.dart';
import 'package:zeta/services/authentication_service.dart';
import 'package:zeta/services/dialog_service.dart';
import 'package:zeta/services/navigation_service.dart';
import 'package:flutter/foundation.dart';

import 'base_model.dart';

class LoginViewModel extends BaseModel {
  final AuthenticationService _authenticationService =
      locator<AuthenticationService>();
  final DialogService _dialogService = locator<DialogService>();
  final NavigationService _navigationService = locator<NavigationService>();
  final AnalyticsService _analyticsService = locator<AnalyticsService>();

  Future login({
    @required String school,
    @required String code,
  }) async {
    setBusy(true);

    // var result = await _authenticationService.loginWithCode(
    //   school: school,
    //   code: code,
    // );

    var result =
        await _authenticationService.loginWithCode(school: school, code: code);
    if (result is bool) {
      // Navigator.push(
      //     context,
      //     MaterialPageRoute(
      //         builder: (context) => HomeView(),
      //         fullscreenDialog: true));
      _navigationService.navigateTo(HomeViewRoute);
    }

    setBusy(false);

    // if (result is bool) {
    //   if (result) {
    //     await _analyticsService.logLogin();
    //     _navigationService.navigateTo(HomeViewRoute);
    //   } else {
    //     await _dialogService.showDialog(
    //       title: 'Login Failure',
    //       description: 'General login failure. Please try again later',
    //     );
    //   }
    // } else {
    //   await _dialogService.showDialog(
    //     title: 'Login Failure',
    //     description: result,
    //   );
    // }
  }
}
