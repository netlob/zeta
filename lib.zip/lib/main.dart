import 'dart:io';

import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:zeta/services/analytics_service.dart';
import 'package:zeta/ui/views/startup_view.dart';
import 'package:flutter/material.dart';
import 'package:zeta/services/navigation_service.dart';
import 'package:zeta/services/dialog_service.dart';
import 'ui/router.dart';
import 'locator.dart';

Box box;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Register all the models and services before the app starts
  setupLocator();

  Directory appDocDirectory = await getApplicationDocumentsDirectory();

  Directory dir =
      await Directory(appDocDirectory.path + '/hive').create(recursive: true);

  var path = dir.path;
  Hive..init(path);

  box = await Hive.openBox('zetaBox');

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    print("myapp()");
    return MaterialApp(
      title: 'Zeta',
      navigatorKey: locator<NavigationService>().navigationKey,
      navigatorObservers: [locator<AnalyticsService>().getAnalyticsObserver()],
      theme: ThemeData(
        primaryColor: Color(0xff19c7c1),
        textTheme: Theme.of(context).textTheme.apply(
              fontFamily: 'Open Sans',
            ),
      ),
      home: StartUpView(),
      onGenerateRoute: generateRoute,
    );
  }
}
