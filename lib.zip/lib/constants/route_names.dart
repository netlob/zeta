const String LoginViewRoute = "LoginView";
const String HomeViewRoute = "HomeView";
// Generate the views here
