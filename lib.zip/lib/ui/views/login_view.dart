import 'package:zeta/ui/shared/ui_helpers.dart';
import 'package:zeta/ui/widgets/busy_button.dart';
import 'package:zeta/ui/widgets/input_field.dart';
import 'package:zeta/ui/widgets/text_link.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:zeta/viewmodels/login_view_model.dart';

class LoginView extends StatefulWidget {
  @override
  _LoginViewState createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final emailController = TextEditingController();

  final passwordController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  String school = "";
  String code = "";
  String error = "";

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<LoginViewModel>.reactive(
      viewModelBuilder: () => LoginViewModel(),
      builder: (context, model, child) => Stack(
        children: <Widget>[
          Center(
              child: Container(
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration(
              // image: DecorationImage(
              //   image: AssetImage('assets/images/login_purple.jpg'),
              //   fit: BoxFit.cover,
              // ),
              color: Colors.blue,
            ),
          )),
          Container(
            child: SafeArea(
              bottom: true,
              child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                return Scaffold(
                  resizeToAvoidBottomPadding: false,
                  backgroundColor: Colors.transparent,
                  body: Form(
                    key: _formKey,
                    child: Stack(
                      children: <Widget>[
                        Container(
                          height: MediaQuery.of(context).size.height,
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            image: DecorationImage(
                              image: AssetImage("assets/images/login_bg.jpg"),
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.all(30),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                "ZETA",
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                    color: Colors.white, fontSize: 30),
                              ),
                              SizedBox(height: 80),
                              // MediaQuery.of(context).copyWith().size.height / 4.5),
                              Center(
                                  child: Text("Welkom\nterug!",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 50,
                                          fontWeight: FontWeight.w800,
                                          height: 1.2))),
                              // SizedBox(height: 20),
                              Container(
                                  height: 100,
                                  child: Row(children: <Widget>[
                                    // Text("https://",
                                    //     style: TextStyle(
                                    //         color: Colors.white,
                                    //         decorationColor: Colors.white,
                                    //         backgroundColor: Colors.transparent,
                                    //         fontSize: 20)),
                                    // SizedBox(width: 10),
                                    Flexible(
                                        child: TextFormField(
                                      cursorColor: Colors.white,
                                      style: TextStyle(
                                          color: Colors.white,
                                          decorationColor: Colors.white,
                                          backgroundColor: Colors.transparent,
                                          fontSize: 20),
                                      decoration: InputDecoration(
                                          enabledBorder: UnderlineInputBorder(
                                            borderSide:
                                                BorderSide(color: Colors.white),
                                          ),
                                          focusedBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.white60),
                                          ),
                                          fillColor: Colors.white,
                                          focusColor: Colors.white,
                                          labelText: 'School',
                                          labelStyle: TextStyle(
                                              color: Colors.white,
                                              fontSize: 20)),
                                      validator: (val) => val.isEmpty ||
                                              val.indexOf(".") > 1
                                          ? "Vul een school in (zonder .zportal.nl)"
                                          : null,
                                      onChanged: (val) =>
                                          setState(() => school = val),
                                    )),
                                    SizedBox(width: 10),
                                    Container(
                                        margin: EdgeInsets.only(top: 30),
                                        child: Text(".zportal.nl",
                                            style: TextStyle(
                                                color: Colors.white,
                                                decorationColor: Colors.white,
                                                backgroundColor:
                                                    Colors.transparent,
                                                fontSize: 20)))
                                  ])),
                              Stack(overflow: Overflow.visible, children: <
                                  Widget>[
                                Container(
                                    height: 100,
                                    child: TextFormField(
                                      obscureText: false,
                                      validator: (val) =>
                                          val.length != 12 && val.length != 15
                                              ? 'Vul een koppelcode in'
                                              : null,
                                      onChanged: (val) =>
                                          setState(() => code = val),
                                      cursorColor: Colors.white,
                                      style: TextStyle(
                                          color: Colors.white,
                                          decorationColor: Colors.white,
                                          backgroundColor: Colors.transparent,
                                          fontSize: 20),
                                      decoration: InputDecoration(
                                          enabledBorder: UnderlineInputBorder(
                                            borderSide:
                                                BorderSide(color: Colors.white),
                                          ),
                                          focusedBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.white60),
                                          ),
                                          fillColor: Colors.white,
                                          focusColor: Colors.white,
                                          labelText: 'Koppel code',
                                          labelStyle: TextStyle(
                                              color: Colors.white,
                                              fontSize: 20)),
                                    )),
                                // SizedBox(height: 10),
                                Positioned(
                                    top: 70,
                                    right: -15,
                                    child: Align(
                                        alignment: Alignment.centerRight,
                                        child: FlatButton(
                                            onPressed: () {},
                                            splashColor: Colors.transparent,
                                            highlightColor: Colors.transparent,
                                            textColor: Colors.black,
                                            child: Text(
                                              "QR code scannen?",
                                              style: TextStyle(
                                                  color: Colors.white54,
                                                  fontSize: 18,
                                                  fontWeight: FontWeight.w200),
                                            ))))
                              ])
                            ],
                          ),
                        ),
                        Positioned(
                            left: 30,
                            bottom: 30,
                            child: Align(
                                alignment: Alignment.bottomCenter,
                                child: Container(
                                  width: MediaQuery.of(context).size.width - 60,
                                  height: 80,
                                  child: RaisedButton(
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(30)),
                                    color: Color.fromRGBO(227, 97, 145, 1),
                                    padding: EdgeInsets.symmetric(vertical: 15),
                                    onPressed: () async {
                                      print("login");
                                      // model.login(school: school, code: code);
                                    },
                                    child: Text(
                                      'Inloggen',
                                      style: TextStyle(
                                          fontSize: 25,
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                )))
                      ],
                    ),
                  ),
                  //     Padding(
                  //   padding: const EdgeInsets.symmetric(horizontal: 50),
                  //   child: Column(
                  //     mainAxisSize: MainAxisSize.max,
                  //     mainAxisAlignment: MainAxisAlignment.center,
                  //     crossAxisAlignment: CrossAxisAlignment.center,
                  //     children: <Widget>[
                  //       SizedBox(
                  //         height: 150,
                  //         child: Image.asset('assets/images/title.png'),
                  //       ),
                  //       InputField(
                  //         placeholder: 'School',
                  //         controller: emailController,
                  //       ),
                  //       verticalSpaceSmall,
                  //       InputField(
                  //         placeholder: 'Code',
                  //         password: true,
                  //         controller: passwordController,
                  //       ),
                  //       verticalSpaceMedium,
                  //       Row(
                  //         mainAxisSize: MainAxisSize.max,
                  //         mainAxisAlignment: MainAxisAlignment.end,
                  //         children: [
                  //           BusyButton(
                  //             title: 'Login',
                  //             busy: model.busy,
                  //             onPressed: () {
                  //               model.login(
                  //                 school: emailController.text,
                  //                 code: passwordController.text,
                  //               );
                  //             },
                  //           )
                  //         ],
                  //       ),
                  //       verticalSpaceMedium,
                  //       TextLink(
                  //         'Create an Account if you\'re new.',
                  //         onPressed: () {
                  //           // model.navigateToSignUp();
                  //         },
                  //       )
                  //     ],
                  //   ),
                  // ),
                );
              }),
            ),
          )
        ],
      ),
    );
  }
}
