import 'package:flutter/material.dart';
import 'package:zeta/zermelo/Zermelo.dart';
import 'package:hive/hive.dart';

import 'package:zeta/locator.dart';
import 'package:zeta/services/authentication_service.dart';
import 'package:zeta/services/navigation_service.dart';

import 'package:zeta/constants/route_names.dart';

class LoginView extends StatefulWidget {
  @override
  _LoginViewState createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final AuthenticationService _authenticationService =
      locator<AuthenticationService>();
  final NavigationService _navigationService = locator<NavigationService>();
  final _formKey = GlobalKey<FormState>();
  final box = Hive.box('zetaBox');

  String school = "";
  String code = "";
  String error = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomPadding: false,
      backgroundColor: Colors.transparent,
      body: Container(
        // height: double.infinity,
        // child: SingleChildScrollView(
        //     child: Container(
        child: Form(
          key: _formKey,
          child: Stack(
            children: <Widget>[
              Container(
                  padding: EdgeInsets.all(30),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          "ZETA",
                          textAlign: TextAlign.left,
                          style: TextStyle(color: Colors.white, fontSize: 30),
                        ),
                        SizedBox(height: 80),
                        // MediaQuery.of(context).copyWith().size.height / 4.5),
                        Center(
                            child: Text("Welkom\nterug!",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 50,
                                    fontWeight: FontWeight.w800,
                                    height: 1.2))),
                        // SizedBox(height: 20),
                        Container(
                            height: 100,
                            child: Row(children: <Widget>[
                              // Text("https://",
                              //     style: TextStyle(
                              //         color: Colors.white,
                              //         decorationColor: Colors.white,
                              //         backgroundColor: Colors.transparent,
                              //         fontSize: 20)),
                              // SizedBox(width: 10),
                              Flexible(
                                  child: TextFormField(
                                cursorColor: Colors.white,
                                style: TextStyle(
                                    color: Colors.white,
                                    decorationColor: Colors.white,
                                    backgroundColor: Colors.transparent,
                                    fontSize: 20),
                                decoration: InputDecoration(
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.white),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.white60),
                                    ),
                                    fillColor: Colors.white,
                                    focusColor: Colors.white,
                                    labelText: 'School',
                                    labelStyle: TextStyle(
                                        color: Colors.white, fontSize: 20)),
                                validator: (val) => val.isEmpty ||
                                        val.indexOf(".") > 1
                                    ? "Vul een school in (zonder .zportal.nl)"
                                    : null,
                                onChanged: (val) =>
                                    setState(() => school = val),
                              )),
                              SizedBox(width: 10),
                              Container(
                                  margin: EdgeInsets.only(top: 30),
                                  child: Text(".zportal.nl",
                                      style: TextStyle(
                                          color: Colors.white,
                                          decorationColor: Colors.white,
                                          backgroundColor: Colors.transparent,
                                          fontSize: 20)))
                            ])),
                        Stack(overflow: Overflow.visible, children: <Widget>[
                          Container(
                              height: 100,
                              child: TextFormField(
                                obscureText: false,
                                validator: (val) =>
                                    val.length != 12 && val.length != 15
                                        ? 'Vul een koppelcode in'
                                        : null,
                                onChanged: (val) => setState(() => code = val),
                                cursorColor: Colors.white,
                                style: TextStyle(
                                    color: Colors.white,
                                    decorationColor: Colors.white,
                                    backgroundColor: Colors.transparent,
                                    fontSize: 20),
                                decoration: InputDecoration(
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.white),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.white60),
                                    ),
                                    fillColor: Colors.white,
                                    focusColor: Colors.white,
                                    labelText: 'Koppel code',
                                    labelStyle: TextStyle(
                                        color: Colors.white, fontSize: 20)),
                              )),
                          // SizedBox(height: 10),
                          Positioned(
                              top: 70,
                              right: -15,
                              child: Align(
                                  alignment: Alignment.centerRight,
                                  child: FlatButton(
                                      onPressed: () {},
                                      splashColor: Colors.transparent,
                                      highlightColor: Colors.transparent,
                                      textColor: Colors.black,
                                      child: Text(
                                        "QR code scannen?",
                                        style: TextStyle(
                                            color: Colors.white54,
                                            fontSize: 18,
                                            fontWeight: FontWeight.w200),
                                      ))))
                        ])
                      ])),
              Positioned(
                  left: 30,
                  bottom: 30,
                  child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        width: MediaQuery.of(context).size.width - 60,
                        height: 80,
                        child: RaisedButton(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30)),
                          color: Color.fromRGBO(227, 97, 145, 1),
                          padding: EdgeInsets.symmetric(vertical: 15),
                          onPressed: () async {
                            if (_formKey.currentState.validate()) {
                              var result = await _authenticationService
                                  .loginWithCode(school: school, code: code);
                              if (result is bool) {
                                // Navigator.push(
                                //     context,
                                //     MaterialPageRoute(
                                //         builder: (context) => HomeView(),
                                //         fullscreenDialog: true));
                                _navigationService.navigateTo(HomeViewRoute);
                              }
                            }
                          },
                          child: Text(
                            'Inloggen',
                            style: TextStyle(
                                fontSize: 25,
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      )))
            ],
          ),
        ),
      ),
    ); //));
  }
}
